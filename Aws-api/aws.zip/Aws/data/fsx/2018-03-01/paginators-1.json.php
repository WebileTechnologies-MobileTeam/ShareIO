<?php
// This file was auto-generated from sdk-root/src/data/fsx/2018-03-01/paginators-1.json
return [ 'pagination' => [ 'DescribeBackups' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], 'DescribeFileSystems' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], ],];
